package com.example.vizesinavi;

public class Email {
    public String header;
    public String desc;
    public String content;
    public String date;

    Email(String _header, String _desc, String _content, String _date){
        header = _header;
        desc = _desc;
        content = _content;
        date = _date;
    }
}
